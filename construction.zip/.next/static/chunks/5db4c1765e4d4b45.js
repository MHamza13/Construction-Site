__turbopack_load_page_chunks__("/_error", [
  "static/chunks/96d2f97fb06cefa1.js",
  "static/chunks/6211052190831b66.js",
  "static/chunks/turbopack-8949eb46c68ce52e.js"
])
