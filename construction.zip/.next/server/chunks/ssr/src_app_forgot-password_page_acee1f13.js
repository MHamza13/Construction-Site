module.exports=[58876,a=>{"use strict";a.s(["default",()=>d]);var b=a.i(87924),c=a.i(18712);function d(){return(0,b.jsx)(c.default,{defaultMode:"forgotPassword"})}}];

//# sourceMappingURL=src_app_forgot-password_page_acee1f13.js.map