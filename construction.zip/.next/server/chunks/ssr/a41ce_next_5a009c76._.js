module.exports = [
"[project]/Downloads/construction/node_modules/next/navigation.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Downloads/construction/node_modules/next/dist/client/components/navigation.js [app-ssr] (ecmascript)");
}),
"[project]/Downloads/construction/node_modules/next/image.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Downloads/construction/node_modules/next/dist/shared/lib/image-external.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=a41ce_next_5a009c76._.js.map