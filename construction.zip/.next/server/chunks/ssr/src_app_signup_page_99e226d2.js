module.exports=[57091,a=>{"use strict";a.s(["default",()=>d]);var b=a.i(87924),c=a.i(18712);function d(){return(0,b.jsx)(c.default,{defaultMode:"signup"})}}];

//# sourceMappingURL=src_app_signup_page_99e226d2.js.map