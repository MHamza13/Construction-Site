globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a41ce_next_dist_compiled_next-devtools_index_48b055cc.js",
      "static/chunks/a41ce_next_dist_compiled_c6bf4ffc._.js",
      "static/chunks/a41ce_next_dist_shared_lib_ce2ff209._.js",
      "static/chunks/a41ce_next_dist_client_b123c67c._.js",
      "static/chunks/a41ce_next_dist_b5c80440._.js",
      "static/chunks/a41ce_next_app_93b1ae3f.js",
      "static/chunks/[next]_entry_page-loader_ts_b162055c._.js",
      "static/chunks/a41ce_react-dom_50973b40._.js",
      "static/chunks/a41ce_1c3d3690._.js",
      "static/chunks/[root-of-the-server]__872f5642._.js",
      "static/chunks/Downloads_construction_pages__app_2da965e7._.js",
      "static/chunks/turbopack-Downloads_construction_pages__app_24a14d88._.js"
    ],
    "/_error": [
      "static/chunks/a41ce_next_dist_compiled_next-devtools_index_48b055cc.js",
      "static/chunks/a41ce_next_dist_compiled_c6bf4ffc._.js",
      "static/chunks/a41ce_next_dist_shared_lib_f620f68b._.js",
      "static/chunks/a41ce_next_dist_client_b123c67c._.js",
      "static/chunks/a41ce_next_dist_44d7d643._.js",
      "static/chunks/a41ce_next_error_6a6a28ff.js",
      "static/chunks/[next]_entry_page-loader_ts_ada9922f._.js",
      "static/chunks/a41ce_react-dom_50973b40._.js",
      "static/chunks/a41ce_1c3d3690._.js",
      "static/chunks/[root-of-the-server]__cfc6e9d7._.js",
      "static/chunks/Downloads_construction_pages__error_2da965e7._.js",
      "static/chunks/turbopack-Downloads_construction_pages__error_0bee6f2b._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a41ce_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6c83c843._.js",
    "static/chunks/a41ce_next_dist_compiled_react-dom_016288f4._.js",
    "static/chunks/a41ce_next_dist_compiled_next-devtools_index_b89bc3d6.js",
    "static/chunks/a41ce_next_dist_compiled_66881b1a._.js",
    "static/chunks/a41ce_next_dist_client_6bc62d0e._.js",
    "static/chunks/a41ce_next_dist_cf1c8acf._.js",
    "static/chunks/a41ce_@swc_helpers_cjs_61dd7978._.js",
    "static/chunks/Downloads_construction_a0ff3932._.js",
    "static/chunks/turbopack-Downloads_construction_8b7a8fda._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];