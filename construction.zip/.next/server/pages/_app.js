var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__3c27927a._.js")
R.m("[project]/Downloads/construction/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Downloads/construction/node_modules/next/app.js [ssr] (ecmascript)").exports
